#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

SSL *ssl;

void *receive_thread(void *arg) {
    char msg[1024];
    while (1) {
        int len = SSL_read(ssl, msg, sizeof(msg) - 1);
        if (len <= 0) break;
        msg[len] = '\0';
        printf("%s", msg);
    }
    return NULL;
}

int main() {
    SSL_library_init();
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();

    const SSL_METHOD *method = TLS_client_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    int sock = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(12345);
    inet_pton(AF_INET, "192.168.1.100", &server.sin_addr); // replace with server IP

    connect(sock, (struct sockaddr *)&server, sizeof(server));

    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, sock);
    if (SSL_connect(ssl) <= 0) {
        ERR_print_errors_fp(stderr);
        return 1;
    }

    char buf[1024], username[50];
    printf("Enter password: ");
    fgets(buf, sizeof(buf), stdin);
    SSL_write(ssl, buf, strlen(buf));

    printf("Enter username: ");
    fgets(username, sizeof(username), stdin);
    SSL_write(ssl, username, strlen(username));

    pthread_t tid;
    pthread_create(&tid, NULL, receive_thread, NULL);

    while (fgets(buf, sizeof(buf), stdin)) {
        SSL_write(ssl, buf, strlen(buf));
    }

    SSL_shutdown(ssl);
    SSL_free(ssl);
    close(sock);
    SSL_CTX_free(ctx);
    return 0;
}
