#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <time.h>

#define PORT 12345
#define MAX_CLIENTS 10
#define PASSWORD "secret123"
#define LOG_FILE "chat.log"

SSL *clients[MAX_CLIENTS];
char usernames[MAX_CLIENTS][50];
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void log_message(const char *msg) {
    FILE *log = fopen(LOG_FILE, "a");
    if (log) {
        fprintf(log, "%s\n", msg);
        fclose(log);
    }
}

char *timestamp() {
    static char buf[64];
    time_t now = time(NULL);
    strftime(buf, sizeof(buf), "[%Y-%m-%d %H:%M:%S]", localtime(&now));
    return buf;
}

void *client_handler(void *arg) {
    int index = *(int *)arg;
    SSL *ssl = clients[index];
    char buf[1024];

    // Authenticate
    SSL_read(ssl, buf, sizeof(buf));
    buf[strcspn(buf, "\n")] = 0;
    if (strcmp(buf, PASSWORD) != 0) {
        SSL_write(ssl, "Authentication failed\n", 23);
        SSL_shutdown(ssl);
        SSL_free(ssl);
        clients[index] = NULL;
        return NULL;
    }

    // Receive username
    SSL_read(ssl, usernames[index], sizeof(usernames[index]));
    usernames[index][strcspn(usernames[index], "\n")] = 0;

    while (1) {
        int len = SSL_read(ssl, buf, sizeof(buf) - 1);
        if (len <= 0) break;
        buf[len] = '\0';

        char msg[1200];
        snprintf(msg, sizeof(msg), "%s %s: %s", timestamp(), usernames[index], buf);
        log_message(msg);

        pthread_mutex_lock(&lock);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i] && i != index) {
                SSL_write(clients[i], msg, strlen(msg));
            }
        }
        pthread_mutex_unlock(&lock);
    }

    SSL_shutdown(ssl);
    SSL_free(ssl);
    pthread_mutex_lock(&lock);
    clients[index] = NULL;
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main() {
    SSL_library_init();
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();

    const SSL_METHOD *method = TLS_server_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    if (!SSL_CTX_use_certificate_file(ctx, "server.crt", SSL_FILETYPE_PEM) ||
        !SSL_CTX_use_PrivateKey_file(ctx, "server.key", SSL_FILETYPE_PEM)) {
        perror("SSL cert/key error");
        return 1;
    }

    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {AF_INET, htons(PORT), INADDR_ANY};
    bind(server_sock, (struct sockaddr *)&addr, sizeof(addr));
    listen(server_sock, MAX_CLIENTS);
    printf("Secure chat server listening on port %d\n", PORT);

    while (1) {
        int client_sock = accept(server_sock, NULL, NULL);
        SSL *ssl = SSL_new(ctx);
        SSL_set_fd(ssl, client_sock);
        if (SSL_accept(ssl) <= 0) {
            SSL_free(ssl);
            continue;
        }

        pthread_mutex_lock(&lock);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (!clients[i]) {
                clients[i] = ssl;
                pthread_t tid;
                int *idx = malloc(sizeof(int));
                *idx = i;
                pthread_create(&tid, NULL, client_handler, idx);
                pthread_detach(tid);
                break;
            }
        }
        pthread_mutex_unlock(&lock);
    }

    close(server_sock);
    SSL_CTX_free(ctx);
    return 0;
}
