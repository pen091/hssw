# Secure C CLI Chat App

## Features
- Username support
- Message timestamps
- Password authentication
- Server-side chat logging
- TLS encryption using OpenSSL

## Requirements
- OpenSSL installed
- Self-signed certificate: `server.crt` and `server.key` must exist in the same directory

## Generate Certificate
```bash
openssl req -x509 -newkey rsa:4096 -keyout server.key -out server.crt -days 365 -nodes
```

## Build
```bash
make
```

## Run Server
```bash
./chat_server
```

## Run Client
Edit the IP in `chat_client.c`, then:
```bash
make chat_client
./chat_client
```
