#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>

int sock;

void *receive_thread(void *arg) {
    char msg[1024];
    while (1) {
        int len = recv(sock, msg, sizeof(msg) - 1, 0);
        if (len <= 0) break;
        msg[len] = '\0';
        printf(">> %s", msg);
    }
    return NULL;
}

int main() {
    struct sockaddr_in server;
    sock = socket(AF_INET, SOCK_STREAM, 0);

    server.sin_family = AF_INET;
    server.sin_port = htons(12345);
    inet_pton(AF_INET, "192.168.1.100", &server.sin_addr); // Replace with actual server IP

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("connect failed");
        return 1;
    }

    pthread_t tid;
    pthread_create(&tid, NULL, receive_thread, NULL);

    char msg[1024];
    while (fgets(msg, sizeof(msg), stdin)) {
        send(sock, msg, strlen(msg), 0);
    }

    close(sock);
    return 0;
}
