# C CLI Chat App

## Build

```bash
make
```

## Run Server

```bash
./chat_server
```

Or install as a service:

```bash
sudo cp chat_server /usr/local/bin/
sudo cp chat_server.service /etc/systemd/system/
sudo systemctl daemon-reexec
sudo systemctl enable --now chat_server.service
```

## Run Client

Edit `chat_client.c` to match your server IP:
```c
inet_pton(AF_INET, "192.168.1.100", &server.sin_addr);
```

Then:

```bash
make chat_client
./chat_client
```

Or install as a service:

```bash
sudo cp chat_client /usr/local/bin/
sudo cp chat_client.service /etc/systemd/system/
sudo systemctl daemon-reexec
sudo systemctl enable --now chat_client.service
```
