#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>

#define PORT 12345
#define MAX_CLIENTS 10

int clients[MAX_CLIENTS];
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void *client_handler(void *arg) {
    int client_sock = *(int *)arg;
    char msg[1024];
    while (1) {
        int len = recv(client_sock, msg, sizeof(msg) - 1, 0);
        if (len <= 0) break;
        msg[len] = '\0';

        pthread_mutex_lock(&lock);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i] && clients[i] != client_sock) {
                send(clients[i], msg, strlen(msg), 0);
            }
        }
        pthread_mutex_unlock(&lock);
    }
    close(client_sock);
    pthread_mutex_lock(&lock);
    for (int i = 0; i < MAX_CLIENTS; i++)
        if (clients[i] == client_sock) clients[i] = 0;
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main() {
    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {AF_INET, htons(PORT), INADDR_ANY};
    bind(server_sock, (struct sockaddr *)&addr, sizeof(addr));
    listen(server_sock, MAX_CLIENTS);
    printf("Server listening on port %d\n", PORT);

    while (1) {
        int client_sock = accept(server_sock, NULL, NULL);
        pthread_mutex_lock(&lock);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (!clients[i]) {
                clients[i] = client_sock;
                pthread_t tid;
                pthread_create(&tid, NULL, client_handler, &clients[i]);
                pthread_detach(tid);
                break;
            }
        }
        pthread_mutex_unlock(&lock);
    }
    return 0;
}
