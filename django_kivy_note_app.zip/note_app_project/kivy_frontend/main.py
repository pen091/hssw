import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
import requests

API_URL = "http://127.0.0.1:8000/api/notes/"

class NoteApp(BoxLayout):
    def add_note(self):
        title = self.ids.title.text
        content = self.ids.content.text
        requests.post(API_URL, json={"title": title, "content": content})
        self.ids.title.text = ''
        self.ids.content.text = ''
        self.load_notes()

    def load_notes(self):
        self.ids.notes_list.text = ''
        response = requests.get(API_URL).json()
        for note in response:
            self.ids.notes_list.text += f"{note['title']}:\n{note['content']}\n\n"

class NotesApp(App):
    def build(self):
        return NoteApp()

if __name__ == "__main__":
    NotesApp().run()
